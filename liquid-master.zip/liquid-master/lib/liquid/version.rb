# encoding: utf-8
module Liquid
  VERSION = "4.0.1"
end
